const { application } = require("express");
const express= require("express");
const router = express.Router();

const mysql = require("mysql");
// 설치했던 노드와 mysql이어주는 모듈 불러오기  (mysql프로그램을 가져오는건 아님!!!)

router.post("/login", function(request, response){

    // 사용자가 입력한  id가 'smart'
    //                 pw가 '123'일때, 성공, 실패시 각각 이동
    let id = request.body.id;
    let pw = request.body.pw;

    if(id == 'smart' && pw == '123'){
        response.redirect("http://127.0.0.1:5500/0322express/public/loginS.html");
    }else{
        response.redirect("http://127.0.0.1:5500/0322express/public/loginF.html");
    }
    response.end();

})

router.post("/join", function(request, response){

    // 사용자가 입력한  id가 'smart'
    //                 pw가 '123'일때, 성공, 실패시 각각 이동
    let id = request.body.id;
    let pw = request.body.pw;
    let nick = request.body.nick;

    // mySQL연결 
    let conn = mysql.createConnection({         // mysql로 아래 필요정보들 넘겨서 허가 떨어지면 conn안에서 기능 활용 가능
        host : '127.0.0.1',
        user : 'root',
        password : '1234',
        port : '3306',
        database : 'nodejs'
    })

    conn.connect();

    let sql = "insert into nodejs_member values(?,?,?)";    // sql문 안의 ;는 안가져와도 됨!!!!   =====> sql문에 바로 변수명을 넣을수는 없음!!! 리터럴 문자열(`${}`) 사용 불가!! 
    conn.query(sql, [id, pw, nick], function(err, rows){              // sql문 실행 후 입력했을때 오류가 나면 err로, 성공하며 rows로 결과값이 들어감!!
        //           사용자가 입력한 값 받아주기 위해서 sql에 ?로 값 비어두고 이 자리에서 순서대로 지정!!!

        if(rows){
            console.log("입력 성공");
            console.log(rows);
        }else{
            console.log("입력 실패");
            console.log(err);    // sql문 틀리면 여기에 저장되어 보여줌!!!!
        }
    });

})


module.exports = router;